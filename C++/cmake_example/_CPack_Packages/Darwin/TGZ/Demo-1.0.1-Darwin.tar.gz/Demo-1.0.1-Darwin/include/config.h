#define USE_MYMATH

#define Demo_VERSION_MAJOR 1
#define Demo_VERSION_MINOR 0
