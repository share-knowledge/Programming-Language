#ifndef cmake_example_math_h_
#define cmake_example_math_h_


extern int add(int a, int b);

#endif // cmake_example_math_h_


